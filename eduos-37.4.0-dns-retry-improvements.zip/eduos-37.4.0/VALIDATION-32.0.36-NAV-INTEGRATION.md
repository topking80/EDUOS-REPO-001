# Validation — EduOS 32.0.36

- Main demo updated with Vision Studio page metadata, renderer and role navigation entries.
- Vision Studio HTML/CSS/JS retained.
- Package versions set to 32.0.36.
- Political source images excluded.
- Browser end-to-end and live database tests not performed.
