# EduOS 32.0.37 — Working Vision Studio Demo

Vision Studio concept cards now open related existing EduOS demo workspaces. Each concept detail view includes an explicit launch action. The embedded page sends a same-origin message; the parent validates origin, exact iframe source, message type and a fixed route allowlist, then checks the active simulated persona's page access before navigation.

This connects the visual library to the actual existing product screens without pretending the illustrative concepts are live integrations. The full district demo, original EduOS artwork, backend, connected workflows and political-content exclusion from the prior release are preserved. Persona switching remains a demo affordance, not a security boundary.

Open **Vision Studio** from the Command Center navigation, choose a concept, then select **Open related EduOS workspace**.
