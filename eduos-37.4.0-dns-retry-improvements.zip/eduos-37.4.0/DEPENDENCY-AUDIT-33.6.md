# EduOS 33.6.0 — Dependency governance audit

- Dependabot npm schedule: weekly Monday 09:00 UTC
- Dependency update PR checks: registry/lockfile policy, clean install, audit, SBOM/license, focused security tests
- Release provenance record: SHA-256 for manifest, lockfile, SBOM; source revision where available
- Auto-merge: disabled
- Cryptographic signature: not configured
- Action pinning: major tags retained; immutable SHA pinning remains recommended
- Package versions changed: none
- Hosted CI and live registry audit: not verified from this build environment
