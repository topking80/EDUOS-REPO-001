# EduOS 33.5.0 — Supply-chain evidence

- Locked npm package entries inventoried: 153
- SPDX SBOM format: SPDX 2.3 JSON
- License metadata: 153 known, 0 unknown in lockfile metadata
- Restricted-license pattern candidates: 0
- Package versions changed: none
- New automated test: `test/supply-chain-33.5.test.js`

The license counts reflect metadata present in the current lockfile and are not legal clearance. Verify license texts and upstream notices before redistribution. A full live npm audit and hosted CI run were not available in this environment.
