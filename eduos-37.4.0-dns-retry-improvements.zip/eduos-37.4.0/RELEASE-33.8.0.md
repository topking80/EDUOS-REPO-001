# EduOS 33.8.0 — Arrival lifecycle backend foundation

- Added database-backed arrival handoff endpoints.
- Enforced bus run and rider assignment checks.
- Required independent staff receipt.
- Gated first attendance on receipt.
- Added tenant RLS and school/role policies.
- Added append-only arrival event history.
- Local tests pass; live PostgreSQL and HTTP integration remain unverified.
- Browser UI remains demo-only pending API integration.
