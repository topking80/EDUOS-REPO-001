Place the approved EduOS mascot runtime asset here as eduos_mascot.riv.
Do not commit an invented or placeholder binary. The Flutter widget falls back
cleanly until the approved Rive file is supplied.
