EduOS 32.0.30 — Classroom graphics expansion

Adds three original SVG visual guides to the teacher classroom planner:
- Classroom zones and circulation
- Teacher workstation
- Accessibility and safety-plan readiness considerations

The graphics are integrated directly beneath the interactive classroom and floor-plan editor. Responsive card layout and descriptive alternative text are included. Graphics are conceptual and do not represent surveyed rooms, certified accessibility layouts or emergency routes.

Run npm ci then npm test in an environment with registry access.
