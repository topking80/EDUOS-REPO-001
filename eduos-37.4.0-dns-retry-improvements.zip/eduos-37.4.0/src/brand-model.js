// Node entry for the shared branding model (public/eduos-brand-model.js).
import "./contrast.js";
import "../public/eduos-brand-model.js";
export const BrandModel = globalThis.EduOSBrandModel;
