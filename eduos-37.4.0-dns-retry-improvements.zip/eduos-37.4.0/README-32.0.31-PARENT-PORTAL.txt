EduOS District Edition 32.0.31 — Parent & Guardian Portal

Added a dedicated Parent & Guardian Portal workspace.

Features:
- Parent navigation entry and dedicated portal page.
- Demonstration learner selector using the existing synthetic learner dataset.
- Attendance snapshot, submitted work, returned grades, upcoming assignments and learning notices.
- Browser-local family notification display preferences.
- Message draft creation and local persistence; drafts are not transmitted.
- JSON family summary export with a synthetic-data disclaimer.
- Privacy and production-integration requirements displayed in the portal.

Important limitations:
- This is a local demonstration feature, not an authenticated parent account system.
- Learner data is synthetic. Do not use for actual student records.
- Guardian verification, relationship authorization, server-side tenant isolation, SIS integration, secure messaging, consent workflows and audit logging require production backend implementation.
- Persona switching and browser storage are not security controls.
