EduOS District Edition 32.0.15 — Project Artwork Expansion

What changed
- Reused the original EduOS architecture, core-services flow, and deployment PNGs in a dedicated responsive gallery on the AI Agents workspace.
- Added an editable SVG operating-model map using the same layer names and palette as the original architecture artwork.
- Mapped the four already-defined agent roles to the architecture as conceptual responsibilities: Christie AI, Helios, Vulcan, and Aurora.
- Added layered framing, color bands, captions, labels, responsive layouts, and accessible descriptions.
- Embedded all artwork in the standalone HTML build.
- Preserved existing deterministic local demo behavior and workflows.

Disclosure
The agent map is conceptual. Dashed links do not represent deployed integrations or live data flows. Existing diagrams remain project reference artwork, not proof of deployed topology or telemetry.

Validation
See docs/VALIDATION-32.0.15.md. Browser visual regression and live database/OIDC integration were not performed.
