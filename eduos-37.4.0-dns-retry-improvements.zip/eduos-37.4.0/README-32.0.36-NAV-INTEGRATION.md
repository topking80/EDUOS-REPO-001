# EduOS 32.0.36 — Vision Studio Navigation Integration

The Vision Studio is embedded in the main district demo shell and exposed as **EduOS Vision Studio** in the Command Center navigation for every role workspace. It loads the re-authored EduOS concept experience in a responsive iframe while preserving the existing demo, backend, workflows and artwork. Open `/` and choose **EduOS Vision Studio** in Command Center. Political source imagery is excluded.
