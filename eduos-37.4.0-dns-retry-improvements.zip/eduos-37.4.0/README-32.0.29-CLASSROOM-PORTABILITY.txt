EduOS District Edition 32.0.29
Classroom layout portability update

Install:
  npm ci
  npm test
  npm start

Teacher workflow:
1. Open the classroom planning workspace.
2. Set teacher/room label, floor, room, desk preference, and layout.
3. Save my preference to store it in this browser.
4. Export layout to move a preference to another browser.
5. Import layout to restore a previously exported JSON preference.

Import accepts only supported floor, room, desk, and arrangement values. Imported files are capped at 32 KB.

Important: the built-in floor plan is illustrative. Actual school drawings and approved emergency procedures must be supplied and verified by authorized school personnel before operational or emergency use. Browser-local preferences are not centrally synchronized.
