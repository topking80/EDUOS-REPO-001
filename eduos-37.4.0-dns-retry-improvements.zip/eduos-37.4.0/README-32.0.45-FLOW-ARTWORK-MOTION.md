# EduOS 32.0.45 — Flow & Artwork Motion

## Experience improvements
- Added a guided four-stage cross-profile workflow explainer to Vision Studio: school action → authorization → event stream → workspace delivery.
- Added step selection, back/next controls and user-controlled play/pause. No background timer runs unless the user starts playback.
- Added animated orbital artwork, agent nodes, subtle card sheen and hover transitions.
- Added responsive workflow layout for narrow screens.
- Added `prefers-reduced-motion` support to suppress decorative animation and transitions.
- Preserved the 45 concept library, interactive district simulator, cross-profile flow/webhook features, edge platform content and existing demo.

## Accuracy and safety
The workflow diagram describes the architecture and safeguards documented in the 32.0.44 release. It is an explainer, not a claim that every event shown is currently firing. Staffing events remain client-reported demo events; server-raised attendance and assignment events retain their existing source distinction. Existing demo-data disclaimers remain in place.
