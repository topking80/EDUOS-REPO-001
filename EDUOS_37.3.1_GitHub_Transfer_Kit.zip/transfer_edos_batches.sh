#!/usr/bin/env bash
set -euo pipefail

REPO_URL="https://github.com/topking80/EDUOS-REPO-001.git"
ARCHIVE="${1:-eduos-37.3.1-webhook-reliability-patch.zip}"
WORKDIR="${2:-$PWD/EDUOS-REPO-001}"

command -v git >/dev/null || { echo "ERROR: git is required."; exit 1; }
command -v unzip >/dev/null || { echo "ERROR: unzip is required."; exit 1; }
command -v rsync >/dev/null || { echo "ERROR: rsync is required."; exit 1; }
[[ -f "$ARCHIVE" ]] || { echo "ERROR: archive not found: $ARCHIVE"; exit 1; }

if [[ ! -d "$WORKDIR/.git" ]]; then
  if [[ -e "$WORKDIR" ]]; then
    echo "ERROR: $WORKDIR exists but is not a Git clone. Choose another WORKDIR."; exit 1
  fi
  git clone "$REPO_URL" "$WORKDIR"
fi

TMPDIR_EDOS="$(mktemp -d)"
trap 'rm -rf "$TMPDIR_EDOS"' EXIT
unzip -q "$ARCHIVE" -d "$TMPDIR_EDOS"

# Resolve the single project directory inside the ZIP.
PACKAGE_JSON="$(find "$TMPDIR_EDOS" -mindepth 2 -maxdepth 3 -type f -name package.json -print | head -n 1)"
if [[ -z "$PACKAGE_JSON" ]]; then
  echo "ERROR: Could not locate project package.json inside archive."; exit 1
fi
PROJECT_DIR="$(dirname "$PACKAGE_JSON")"

cd "$WORKDIR"
git switch main
git pull --ff-only origin main

# Copy source while preserving .git and the repository's existing README.
# Exclude generated dependencies, local secrets, caches, and local runtime state.
rsync -a --ignore-existing \
  --exclude='.git/' --exclude='node_modules/' --exclude='.env' --exclude='.env.*' \
  --exclude='*.pem' --exclude='*.key' --exclude='*.p12' --exclude='id_rsa*' \
  --exclude='coverage/' --exclude='.eden-dev/' --exclude='*.log' \
  "$PROJECT_DIR/" ./

commit_batch() {
  local label="$1"; shift
  git add -- "$@"
  if ! git diff --cached --quiet; then
    git commit -m "$label"
    git push origin main
  else
    echo "Skipping empty batch: $label"
  fi
}

# Batch 1: root configuration, package manifests, workflows, and project docs.
commit_batch "Import EdOS 37.3.1: project configuration and documentation" \
  . ':!.git' ':!db' ':!src' ':!test' ':!edge-platform' ':!mobile' ':!public' \
  ':!scripts' ':!deploy' ':!dev' ':!demo' ':!platform' ':!artifacts'

# Batch 2: database schema, initialization, upgrades, and migrations.
[[ ! -d db ]] || commit_batch "Import EdOS 37.3.1: database migrations and schema" db

# Batch 3: application source and automated tests.
[[ ! -d src ]] || commit_batch "Import EdOS 37.3.1: application source" src
[[ ! -d test ]] || commit_batch "Import EdOS 37.3.1: automated tests" test

# Batch 4: edge runtime and mobile client.
[[ ! -d edge-platform ]] || commit_batch "Import EdOS 37.3.1: edge platform" edge-platform
[[ ! -d mobile ]] || commit_batch "Import EdOS 37.3.1: mobile application" mobile

# Batch 5: public assets and supporting platform, deployment, scripts, demos.
for path in public scripts deploy dev demo platform artifacts; do
  [[ ! -e "$path" ]] || commit_batch "Import EdOS 37.3.1: $path" "$path"
done

# Pick up any remaining non-secret source files not covered above.
git add -A
git diff --cached --quiet || {
  git commit -m "Import EdOS 37.3.1: remaining project files"
  git push origin main
}

echo
echo "Transfer batches complete. Latest commit:"
git log -1 --oneline
echo "Working tree status:"
git status --short
