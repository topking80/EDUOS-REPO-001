# EdOS 37.3.1 — Batched GitHub Transfer

Repository: https://github.com/topking80/EDUOS-REPO-001
Source archive: `eduos-37.3.1-webhook-reliability-patch.zip`

## What this transfer does

- Clones the existing repository and preserves its Git history.
- Copies the EdOS source into the repository without copying `.git` or `node_modules`.
- Excludes local environment files, private-key files, logs, caches, and local runtime state.
- Preserves an existing repository file rather than overwriting it during copy (including the current README).
- Creates separate commits and pushes them in logical batches: root configuration/docs, database, application source, tests, edge platform, mobile, and supporting assets/deployment/scripts.

## Requirements

Run this from a Mac, Linux, or a GitHub Codespaces terminal with `git`, `unzip`, and `rsync` installed. GitHub's iPhone web interface is not a practical way to upload hundreds of files in batches.

## Steps

1. Put `eduos-37.3.1-webhook-reliability-patch.zip` and `transfer_edos_batches.sh` in the same folder.
2. Open Terminal in that folder (or open a Codespaces terminal with both files available).
3. Run:

   ```bash
   chmod +x transfer_edos_batches.sh
   ./transfer_edos_batches.sh eduos-37.3.1-webhook-reliability-patch.zip
   ```

4. If Git prompts for authentication, complete the GitHub sign-in flow. Do not paste a password or token into chat.
5. After it finishes, check https://github.com/topking80/EDUOS-REPO-001/commits/main and confirm the batch commits appear.

## Batch sequence

1. Root configuration, package manifests, GitHub workflows, and project documentation.
2. Database migrations and schema.
3. Application source (`src/`).
4. Automated tests (`test/`).
5. Edge platform (`edge-platform/`).
6. Mobile application (`mobile/`).
7. Public assets, scripts, deployment, dev tools, demos, platform, and artifacts.

## Important safeguards

- This script targets `main` and performs a fast-forward pull before copying.
- It does not force-push or rewrite history.
- It does not copy `node_modules`; dependencies should be installed from the lockfile after transfer.
- It does not overwrite files already present in the destination clone. Review any skipped filename conflicts manually.
- The script does not run tests or claim the project is production-ready. After import, install dependencies and run the project's documented validation commands, then complete PostgreSQL/RLS staging checks.
